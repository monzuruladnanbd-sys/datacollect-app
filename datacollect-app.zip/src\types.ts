// Types moved to src/lib/session.ts to avoid circular imports
